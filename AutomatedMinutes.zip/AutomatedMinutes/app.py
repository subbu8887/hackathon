from __future__ import absolute_import
from __future__ import print_function
from flask import Flask, render_template, request, redirect, jsonify, session
import speech_recognition as sr
import os
from pydub import AudioSegment
from pydub.silence import split_on_silence

import six

import rake
import operator
import io

from datetime import datetime
import datefinder
import json
import time

app = Flask(__name__)

app.secret_key = 'dljsaklqk24e21cjn!Ew@@dsa5'


@app.route("/", methods=["GET", "POST"])
def index():
    audiofile = ""
    transcript = ""
    summary = ""

    if request.method == "POST":
        print("FORM DATA RECEIVED")

        if request.form['submit_button'] == 'Audio':
            audiofile = file_select()  # do something
            session["audiofile"] = audiofile
            transcript = ""
            session["transcript"] =""
            session["summary"] =""
            return render_template('index.html', audiofile=audiofile, transcript=transcript)
        elif request.form['submit_button'] == 'Transcribe':
            if session["audiofile"] == "":
                transcript = "Please select the meeting audio file."
                return render_template('index.html', audiofile=audiofile, transcript=transcript)

            else:
                transcript = transcribe()  # do something else
                #session["audiofile"] = ""
                session["transcript"] = transcript
                audiofile = ""
                return render_template('index.html', audiofile=audiofile, transcript=transcript)
        elif request.form['submit_button'] == 'Summary':
            print("** Inside Summary " + session["transcript"])
            summary_combined = minutes_summary(session["transcript"])  # do something else
            summary_array = summary_combined.split("|")
            summary = summary_array[1]
            action = summary_array[0]
            audiofile = session["audiofile"]
            transcript = session["transcript"]
            return render_template('index.html', audiofile=audiofile, transcript=transcript, action=action, summary=summary )
        else:
            pass  # unknown
    elif request.method == 'GET':
        return render_template('index.html', audiofile=audiofile, transcript=transcript)

def file_select():
    from tkinter import Tk
    from tkinter.filedialog import askopenfilename
    root = Tk()
    root.withdraw()
    # ensure the file dialog pops to the top window
    root.wm_attributes('-topmost', 1)
    audiofile = askopenfilename(parent=root)
    print("filepath:")
    print(audiofile)
    return audiofile
    session["audiofile"] = audiofile
    # return jsonify({'filepath': audiofile})
    # return render_template('audio.html', audiofile = audiofile )


def transcribe():
    file = session.get("audiofile", None)
    # file = audiofile
    print("*************** filename: ")
    print(file)
    # return file

    # if file:
    #    print("File: ")
    #    print(file)
    transcript = audio_to_Text(file)
    return transcript
    # return render_template('transcribe.html', transcript=transcript)
    # return render_template('index1.html', transcript="hi world..##")


#setting silence
m_silence=500
silence_thresh=15
k_silence=500
r = sr.Recognizer()
#function to return audio to text
def audio_to_Text(_path):
    print(">>>>>>>>>>> Filename >>>>>>>>>")
    print(_path)

    sound = AudioSegment.from_wav(_path)
    chunks = split_on_silence(sound,
        min_silence_len = m_silence,
        silence_thresh = sound.dBFS-silence_thresh,
        keep_silence=k_silence,
    )
    folder_name = "audio-chunks"
    if not os.path.isdir(folder_name):
        os.mkdir(folder_name)
    whole_text = ""
    for i, audio_chunk in enumerate(chunks, start=1):
        chunk_filename = os.path.join(folder_name, f"chunk{i}.wav")
        audio_chunk.export(chunk_filename, format="wav")
        with sr.AudioFile(chunk_filename) as source:
            audio_listened = r.record(source)
            try:
                #
                text = r.recognize_wit(audio_listened,key="56Q356IFKDZD5AS6QXCXFERECFA2G44E")
            except sr.UnknownValueError as e:
                print("Error:", str(e))
            else:
                text = f"{text.capitalize()}. "
                print(chunk_filename, ":", text)
                whole_text += text

    return whole_text

sentencesArray = {}
keywordsArray = {}
phrasesArray = {}
datesArray = {}
sentencesWithDatesArray = {}


def findDates(keyword):
    dates_with_sentences = ''
    matches = datefinder.find_dates(keyword)
    for match in matches:
        sentencesWithDatesArray[keyword] = str(datetime.date(match))
        print(match)

    convertToJSON('output_data/dates.txt', sentencesWithDatesArray)



def dumpToFile(fileName, data):
    f = open(fileName, 'w')
    f.write(data)
    f.close()


def convertToJSON(fileName, data):
    with open(fileName, 'w', encoding="utf8") as outfile:
        json.dump(data, outfile)

def minutes_summary(transcript_input):
    stoppath = "data/stoplists/SmartStoplist.txt"

    # 1. initialize RAKE by providing a path to a stopwords file
    rake_object = rake.Rake(stoppath, 5, 3, 5)

    # 2. run on RAKE on a given text
    sample_file = io.open("data/chat.txt", 'r', encoding="iso-8859-1")
    #text = sample_file.read()

    print("#############transcript_input")
    print(transcript_input)
    text = transcript_input

    keywords = rake_object.run(text)

    rake_object = rake.Rake(stoppath)

    # 1. Split text into sentences
    sentenceList = rake.split_sentences(text)

    # generate candidate keywords
    stopwords = rake.load_stop_words(stoppath)
    stopwordpattern = rake.build_stop_word_regex(stoppath)
    phraseList = rake.generate_candidate_keywords(sentenceList, stopwordpattern, stopwords)

    # calculate individual word scores
    wordscores = rake.calculate_word_scores(phraseList)

    # generate candidate keyword scores
    keywordcandidates = rake.generate_candidate_keyword_scores(phraseList, wordscores)

    # sort candidates by score to determine top-scoring keywords
    sortedKeywords = sorted(six.iteritems(keywordcandidates), key=operator.itemgetter(1), reverse=True)
    totalKeywords = len(sortedKeywords)

    popularSentences = {}
    popularKeywords = {}

    for sentence in sentenceList:
        if sentence:
            findDates(sentence)
    i = 0
    j = 0
    for keyword in keywords:
        i += 1
        popularKeywords[i] = keyword[0]
        nextSentence = 0
        for sentence in sentenceList:
            sentence =sentence.strip()
            if nextSentence == 1:
                j += 1
                if len(sentence.split(' ')) > 8:
                    popularSentences[j] =sentence.strip()
                    print("************* " + sentence + str(len(sentence.split(' '))))
                nextSentence = 0

            if keyword[0] in sentence:
                j += 1
                nextSentence = 1
                if len(sentence.split(' ')) > 8:
                    popularSentences[j] = sentence


    convertToJSON('output_data/popular_sentences.txt', popularSentences)
    convertToJSON('output_data/popular_keywords.txt', popularKeywords)
    action_item = io.open("output_data/dates.txt", 'r', encoding="iso-8859-1")
    action_item_text = action_item.read()

    sentences_file = io.open("output_data/popular_sentences.txt", 'r', encoding="iso-8859-1")
    sentences_text = sentences_file.read()

    summary_output = action_item_text + "|" + sentences_text


    print(">>>>>>>>>>>>>>.minutes Summary")
    #minutes = "Please join role as for your area of interest and attend the training. Has anybody got any questions at all no thank you we can move on to our next item then which is odee website. Raj. Have you got any updates on that yep. So just to say that. Hey portal website is due to go next month. I have made some updates in terms of the program of events. It's going to be updated frequently so. Stop conceited what workshops are going to be like in on a daily basis that sounds fantastic. Thank you very much."
    print(summary_output)
    return summary_output


if __name__ == "__main__":
    app.run(debug=True, threaded=True)
